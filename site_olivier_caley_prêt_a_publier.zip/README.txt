SITE OFFICIEL — OLIVIER CALEY

Contenu
-------
- index.html : le site complet, autonome et responsive.
- Aucun logiciel payant n'est nécessaire.

MISE EN LIGNE GRATUITE — méthode simple avec GitHub Pages
---------------------------------------------------------
1. Créez un compte gratuit sur GitHub.
2. Créez un nouveau dépôt nommé par exemple : olivier-caley
3. Ajoutez le fichier index.html à la racine du dépôt.
4. Dans Settings > Pages :
   - Source : Deploy from a branch
   - Branch : main
   - Folder : / (root)
5. Enregistrez.
6. Votre site sera accessible avec une adresse du type :
   https://votre-identifiant.github.io/olivier-caley/

À PERSONNALISER AVANT PUBLICATION
---------------------------------
Dans index.html :
- Remplacez les deux liens href="#" des boutons "Voir le livre".
- Remplacez votre-adresse@example.com par une adresse de contact.
- Si vous avez les couvertures des romans, elles peuvent remplacer les blocs texte actuels.
- Une photo d'auteur peut également être ajoutée.

Le site fonctionne aussi gratuitement sur Cloudflare Pages ou Netlify.
